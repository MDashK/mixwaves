
 8888888b.                                         888888b.                              
 888   Y88b                                        888  "88b                             
 888    888                                        888  .88P                             
 888   d88P .d88b.  888  888  888  .d88b.  888d888 8888888K.   8888b.  .d8888b   .d88b.  
 8888888P" d88""88b 888  888  888 d8P  Y8b 888P"   888  "Y88b     "88b 88K      d8P  Y8b 
 888       888  888 888  888  888 88888888 888     888    888 .d888888 "Y8888b. 88888888 
 888       Y88..88P Y88b 888 d88P Y8b.     888     888   d88P 888  888      X88 Y8b.     
 888        "Y88P"   "Y8888888P"   "Y8888  888     8888888P"  "Y888888  88888P'  "Y8888  


                          It All Started With The Icon...

    PowerBase is a Sega Master System and Game Gear emulator based on
    DEGA v1.12 by Dave. It works on Windows Systems Only.

    Created by: MDashK, 2012, MixWaves.
    E-Mail: powerbase@mixwaves.zzn.com
    URL: http://www.mixwaves.webs.com/powerbase.htm

    FREEWARE SOFTWARE

    Disclaimer (as always):
      I do not accept responsibility for any effects, adverse or otherwise,
      that this program and code may have on you, your computer, your sanity,
      your dog, your mother, or/and anything else that you can think of.
      Use it at your own risk. You can use this software freely as long as
      you don't use it commercially.

____________________________________________________________________________________

                                What's New?

  v2.58
  -----

  + Added Version info to the program
  + Now you can check the Controls of the emulator in it's own section

  * Removed "Controls" from the About box. Now they have they're own dialog.

  - Started implementation of Key Mapping in the emulator but I gave up
    on that. Realized it's not worth it...
  - Thought about informing when changed overlays, like used in Pause/Unpause
    of emulation, but also decided there's no need for that...
  - One thing I would like to add to the emulator would be Scanlines, but I'm
    having a hard time trying to figure that out... If you would like to help
    send an e-mail to the address mentioned in the emulator. Proper credit will
    be given in the About and ReadMe. =) Thanks.

  v2.37
  -----

  + Added screen multiplier option. Can multiply screen resolution size up to 4x
    (Won't work on fullscreen mode, only windowed mode)
  + The emulator now saves the current resolution size and fullscreen option
    to the config file. So if you close the emulator in fullscreen, it will open
    in fullscreen. That applies to the 2x, 3x, 4x options as well.
    The StartInFullScreen option is still available. But this option is only
    changeable if you modify the power.ini manually.
  + Added About dialog (Yey =) )

  * One step frame is now only possible to use IF emulation is paused
    (wouldn't work unpaused anyways, at least not in a noticeable matter).
  * The emulator used to calculate the desktop area and create and size the
    window of the emulator accordingly. That provided incorrect sizing of
    display render. Now instead of that, the window resizes depending if it is
    SMS or GG game, and resizes to original render values.
  * Default overlay is now None.

  - Removed capacity of skipping with F8 key (sorry, don't want it =P)
  - Menu is always showed in windowed mode. In fullscreen mode, hidding is     
    possible. (I prefer it that way)
  - Removed some unnecessary hotkeys and re-arranged others
  - Compatibility is not 100% has you know. Some SMS and GG games won't work
    correctly, or at all. "Sonic Drift" is one of those games.

____________________________________________________________________________________

                                How to use

  Run the emulator and select Load ROM from the File menu.
  Select a ROM and click open. The keys are:

  Up,Down,Left,Right = Cursor keys (not on the numpad)
  Fire 1,Fire 2      = Z,X
  Pause/Start        = C
  (On Master System, the "Start" button is Fire 2. C is Pause only.)

____________________________________________________________________________________

				FAQ

Q: It started because of an icon?
A: I had the icon of the emulator lying around the computer, I wanted to use the icon
for something, but not just anything. Something that would relate to it. An emulator
sounded like the best choice. So I searched for an open source SMS emulator that I
could enhance somehow, mainly for my personal interest. I found DEGA. Above that, it's
an emulator that I like, always liked, and of course, always used. For years. So I
decided to work on it. Checked out other emulators, functions that they have and Dega
doesn't have, and implement them on Dega.

Q: Why PowerBase?
A: When I started the project I really didn't have a name for the emulator...
I have 2 SMS systems: A Sega Master System II and a Sega Master System III
(only released by TecToy in Brazil and Portugal). The III is operacional but the II
it's broken. But I keep it in my PC desk for decoration. So I looked at the console,
and saw the SEGA logo and reffering "Power Base" beneath... It clicked.

Q: Why version 2.xx? Where are the others?
A: The emulator is based in the source code of Dega v1.12. So, Dega beeing version 1,
I think version 2 would sound better to the emulator, since it's an enhancement of the
first one. The last 2 digits are the build version. This means: If it's version 54,
for example, means I already created the EXE 54 times! Even for test purposes. So there
will be a lot of versions you won't see.

____________________________________________________________________________________

                           Special Thanks

  * Dave for his genious work on creating Dega.
  * Peter Collingbourne for the Dega (rerecording) project
    (It helps keeping DEGA alive =) )
  * "Mim..." for her patience

____________________________________________________________________________________


    #      #   #                              ## #        ##########            
   ####### #   #   ########## #########     ##   #   ###  #        # ########## 
  #     #  #   #           #  #       #   ## #   ####             #          #  
 # #   #   #   #          #   #       # ##   #   #               #          #   
    ###       #        # #    #       #      #   #              #        # #    
   ##        #          #     #########      #   #            ##          #     
 ##        ##            #                   #    #######   ##             #    


- MDashK

[EoF]